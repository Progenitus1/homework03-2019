package cz.muni.fi.pb162.find.impl.filters;

import org.junit.Test;

/**
 * @author pstanko
 */
public class FileContentFilterActionTest {
    @Test
    public void filter() throws Exception {

    }

}